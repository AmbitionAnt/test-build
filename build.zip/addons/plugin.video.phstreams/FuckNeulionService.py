import subprocess
import sys

subprocess.call("/usr/bin/python /storage/.kodi/addons/plugin.video.phstreams/jars/FuckNeulionService.py &", shell=True)
